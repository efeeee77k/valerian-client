package com.valerian.hud.elements;

import com.valerian.hud.HudElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class FpsElement extends HudElement {

	public FpsElement(int x, int y) {
		super("FPS", x, y, 50, 12);
	}

	@Override
	public void render(DrawContext context) {
		MinecraftClient mc = MinecraftClient.getInstance();
		String text = "FPS: " + mc.getCurrentFps();
		context.drawText(mc.textRenderer, text, x, y, 0xFFFFFFFF, true);
		this.width = mc.textRenderer.getWidth(text) + 4;
	}
}

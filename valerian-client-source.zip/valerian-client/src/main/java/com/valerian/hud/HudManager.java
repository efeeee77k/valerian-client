package com.valerian.hud;

import com.valerian.hud.elements.*;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public class HudManager {

	public static final List<HudElement> elements = new ArrayList<>();
	public static boolean editMode = false;

	public static void init() {
		elements.add(new FpsElement(5, 5));
		elements.add(new CoordinatesElement(5, 20));
		elements.add(new PingElement(5, 35));
		elements.add(new DirectionElement(5, 50));
		elements.add(new ArmorElement(5, 70));
		elements.add(new KeystrokesElement(100, 5));
		elements.add(new PotionElement(5, 150));
		elements.add(new TargetHudElement(200, 5));
	}

	public static void render(DrawContext context) {
		for (HudElement element : elements) {
			if (element.enabled) {
				element.render(context);
			}
		}
	}

	public static HudElement getHovered(double mouseX, double mouseY) {
		for (int i = elements.size() - 1; i >= 0; i--) {
			HudElement e = elements.get(i);
			if (e.enabled && e.isMouseOver(mouseX, mouseY)) {
				return e;
			}
		}
		return null;
	}
}

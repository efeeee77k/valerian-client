package com.valerian.hud.elements;

import com.valerian.hud.HudElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;

public class PotionElement extends HudElement {

	public PotionElement(int x, int y) {
		super("Potions", x, y, 120, 60);
	}

	@Override
	public void render(DrawContext context) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null) return;

		int drawY = y;
		for (StatusEffectInstance effect : mc.player.getStatusEffects()) {
			String name = effect.getEffectType().value().getName().getString();
			int duration = effect.getDuration() / 20;
			String text = name + " " + (duration / 60) + ":" + String.format("%02d", duration % 60);
			context.drawText(mc.textRenderer, text, x, drawY, 0xFFFFFFFF, true);
			drawY += 12;
		}
		this.height = Math.max(12, drawY - y);
	}
}

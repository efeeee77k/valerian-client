package com.valerian.hud.elements;

import com.valerian.hud.HudElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

public class PingElement extends HudElement {

	public PingElement(int x, int y) {
		super("Ping", x, y, 50, 12);
	}

	@Override
	public void render(DrawContext context) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.getNetworkHandler() == null) return;

		PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
		int ping = entry != null ? entry.getLatency() : 0;

		String text = "Ping: " + ping + "ms";
		context.drawText(mc.textRenderer, text, x, y, 0xFFFFFFFF, true);
		this.width = mc.textRenderer.getWidth(text) + 4;
	}
}

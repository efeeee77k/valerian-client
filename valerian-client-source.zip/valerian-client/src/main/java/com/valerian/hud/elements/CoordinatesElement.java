package com.valerian.hud.elements;

import com.valerian.hud.HudElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class CoordinatesElement extends HudElement {

	public CoordinatesElement(int x, int y) {
		super("Coordinates", x, y, 120, 12);
	}

	@Override
	public void render(DrawContext context) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null) return;

		String text = String.format("XYZ: %.1f %.1f %.1f",
				mc.player.getX(), mc.player.getY(), mc.player.getZ());
		context.drawText(mc.textRenderer, text, x, y, 0xFFFFFFFF, true);
		this.width = mc.textRenderer.getWidth(text) + 4;
	}
}

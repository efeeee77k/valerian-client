package com.valerian.hud.elements;

import com.valerian.hud.HudElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

public class KeystrokesElement extends HudElement {

	public KeystrokesElement(int x, int y) {
		super("Keystrokes", x, y, 70, 50);
	}

	@Override
	public void render(DrawContext context) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null) return;

		drawKey(context, mc, "W", mc.options.forwardKey, x + 22, y);
		drawKey(context, mc, "A", mc.options.leftKey, x, y + 16);
		drawKey(context, mc, "S", mc.options.backKey, x + 22, y + 16);
		drawKey(context, mc, "D", mc.options.rightKey, x + 44, y + 16);
		drawKey(context, mc, "LMB", mc.options.attackKey, x, y + 32);
		drawKey(context, mc, "RMB", mc.options.useKey, x + 35, y + 32);
	}

	private void drawKey(DrawContext context, MinecraftClient mc, String label, KeyBinding key, int px, int py) {
		boolean pressed = key.isPressed();
		int color = pressed ? 0xFF00C853 : 0xAA222233;
		context.fill(px, py, px + 20, py + 14, color);
		context.drawCenteredTextWithShadow(mc.textRenderer, label, px + 10, py + 3, 0xFFFFFFFF);
	}
}

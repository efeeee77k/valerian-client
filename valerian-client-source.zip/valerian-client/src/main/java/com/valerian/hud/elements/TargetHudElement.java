package com.valerian.hud.elements;

import com.valerian.hud.HudElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class TargetHudElement extends HudElement {

	public TargetHudElement(int x, int y) {
		super("TargetHUD", x, y, 120, 30);
	}

	@Override
	public void render(DrawContext context) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.crosshairTarget == null) return;
		if (mc.crosshairTarget.getType() != HitResult.Type.ENTITY) return;

		Entity entity = ((EntityHitResult) mc.crosshairTarget).getEntity();
		if (!(entity instanceof LivingEntity living)) return;

		String name = living.getName().getString();
		float health = living.getHealth();
		float maxHealth = living.getMaxHealth();

		context.fill(x, y, x + width, y + height, 0xAA111122);
		context.drawText(mc.textRenderer, name, x + 4, y + 4, 0xFFFFFFFF, true);

		// Can barı
		int barWidth = width - 8;
		int filled = (int) ((health / maxHealth) * barWidth);
		context.fill(x + 4, y + 16, x + 4 + barWidth, y + 24, 0xFF333333);
		context.fill(x + 4, y + 16, x + 4 + filled, y + 24, 0xFF00C853);
		context.drawText(mc.textRenderer, String.format("%.1f", health), x + 6, y + 17, 0xFFFFFFFF, false);
	}
}

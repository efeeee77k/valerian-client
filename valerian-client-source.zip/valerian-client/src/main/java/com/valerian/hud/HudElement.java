package com.valerian.hud;

import net.minecraft.client.gui.DrawContext;

public abstract class HudElement {

	public String name;
	public int x, y;
	public int width, height;
	public boolean enabled = true;
	public boolean dragging = false;
	public int dragOffsetX, dragOffsetY;

	public HudElement(String name, int x, int y, int width, int height) {
		this.name = name;
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}

	public abstract void render(DrawContext context);

	public boolean isMouseOver(double mouseX, double mouseY) {
		return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
	}

	public void startDrag(double mouseX, double mouseY) {
		dragging = true;
		dragOffsetX = (int) (mouseX - x);
		dragOffsetY = (int) (mouseY - y);
	}

	public void updateDrag(double mouseX, double mouseY) {
		if (dragging) {
			x = (int) (mouseX - dragOffsetX);
			y = (int) (mouseY - dragOffsetY);
		}
	}

	public void stopDrag() {
		dragging = false;
	}
}

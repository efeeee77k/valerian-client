package com.valerian.hud.elements;

import com.valerian.hud.HudElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public class ArmorElement extends HudElement {

	public ArmorElement(int x, int y) {
		super("Armor", x, y, 80, 70);
	}

	@Override
	public void render(DrawContext context) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null) return;

		int drawY = y;
		EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

		for (EquipmentSlot slot : slots) {
			ItemStack stack = mc.player.getEquippedStack(slot);
			if (!stack.isEmpty()) {
				context.drawItem(stack, x, drawY);
				context.drawItemInSlot(mc.textRenderer, stack, x, drawY);
			}
			drawY += 16;
		}
	}
}

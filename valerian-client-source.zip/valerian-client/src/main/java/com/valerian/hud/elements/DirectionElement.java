package com.valerian.hud.elements;

import com.valerian.hud.HudElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class DirectionElement extends HudElement {

	public DirectionElement(int x, int y) {
		super("Direction", x, y, 40, 12);
	}

	@Override
	public void render(DrawContext context) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null) return;

		float yaw = mc.player.getYaw();
		String dir = getDirection(yaw);

		String text = "Dir: " + dir;
		context.drawText(mc.textRenderer, text, x, y, 0xFFFFFFFF, true);
		this.width = mc.textRenderer.getWidth(text) + 4;
	}

	private String getDirection(float yaw) {
		yaw = yaw % 360;
		if (yaw < 0) yaw += 360;

		if (yaw >= 337.5 || yaw < 22.5) return "S";
		if (yaw < 67.5) return "SW";
		if (yaw < 112.5) return "W";
		if (yaw < 157.5) return "NW";
		if (yaw < 202.5) return "N";
		if (yaw < 247.5) return "NE";
		if (yaw < 292.5) return "E";
		return "SE";
	}
}

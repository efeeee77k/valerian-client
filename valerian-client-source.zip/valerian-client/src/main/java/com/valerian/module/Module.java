package com.valerian.module;

public class Module {

	private final String name;
	private final Category category;
	private boolean enabled;
	private final String description;

	public Module(String name, Category category, String description) {
		this.name = name;
		this.category = category;
		this.description = description;
		this.enabled = false;
	}

	public String getName() {
		return name;
	}

	public Category getCategory() {
		return category;
	}

	public String getDescription() {
		return description;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
		if (enabled) {
			onEnable();
		} else {
			onDisable();
		}
	}

	public void toggle() {
		setEnabled(!enabled);
	}

	public void onEnable() {}
	public void onDisable() {}
	public void onTick() {}
}

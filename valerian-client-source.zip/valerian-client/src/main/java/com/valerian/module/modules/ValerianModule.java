package com.valerian.module.modules;

import com.valerian.module.Category;
import com.valerian.module.Module;

public class ValerianModule extends Module {

	public ValerianModule() {
		super("Valerian", Category.CLIENT, "Change the menu open keybind");
	}

	// Keybind değiştirme menüsü sonra eklenecek.
	// Şimdilik sadece yer tutucu.
}

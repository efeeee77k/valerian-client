package com.valerian.module.modules;

import com.valerian.module.Category;
import com.valerian.module.Module;

import java.util.HashSet;
import java.util.Set;

public class FriendsModule extends Module {

	public static final Set<String> friends = new HashSet<>();

	public FriendsModule() {
		super("Friends", Category.CLIENT, "Manage your friends list");
	}

	public static boolean isFriend(String name) {
		return friends.contains(name.toLowerCase());
	}

	public static void addFriend(String name) {
		friends.add(name.toLowerCase());
	}

	public static void removeFriend(String name) {
		friends.remove(name.toLowerCase());
	}

	public static void toggleFriend(String name) {
		String lower = name.toLowerCase();
		if (friends.contains(lower)) {
			friends.remove(lower);
		} else {
			friends.add(lower);
		}
	}
}

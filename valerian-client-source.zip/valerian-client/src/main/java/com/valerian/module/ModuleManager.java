package com.valerian.module;

import com.valerian.module.modules.ChatKeybindModule;
import com.valerian.module.modules.FriendsModule;
import com.valerian.module.modules.HitboxModule;
import com.valerian.module.modules.NameProtectModule;
import com.valerian.module.modules.SkinProtectModule;
import com.valerian.module.modules.SprintModule;
import com.valerian.module.modules.SwingSpeedModule;
import com.valerian.module.modules.ValerianModule;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {

	private static final List<Module> modules = new ArrayList<>();

	public static void init() {
		// Combat
		modules.add(new HitboxModule());

		// Misc
		modules.add(new NameProtectModule());
		modules.add(new SkinProtectModule());
		modules.add(new SprintModule());
		modules.add(new SwingSpeedModule());

		// Client
		modules.add(new ValerianModule());
		modules.add(new ChatKeybindModule());
		modules.add(new FriendsModule());
	}

	public static List<Module> getModules() {
		return modules;
	}

	public static List<Module> getModulesByCategory(Category category) {
		List<Module> result = new ArrayList<>();
		for (Module m : modules) {
			if (m.getCategory() == category) {
				result.add(m);
			}
		}
		return result;
	}

	public static Module getModuleByName(String name) {
		for (Module m : modules) {
			if (m.getName().equalsIgnoreCase(name)) {
				return m;
			}
		}
		return null;
	}

	public static void onTick() {
		for (Module m : modules) {
			if (m.isEnabled()) {
				m.onTick();
			}
		}
	}
}

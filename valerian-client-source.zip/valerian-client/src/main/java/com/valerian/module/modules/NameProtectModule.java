package com.valerian.module.modules;

import com.valerian.module.Category;
import com.valerian.module.Module;
import net.minecraft.client.MinecraftClient;

public class NameProtectModule extends Module {

	public NameProtectModule() {
		super("NameProtect", Category.MISC, "Hides your real name");
	}

	public static String getProtectedName() {
		return "Valerian"; // İstediğin ismi buraya yazabilirsin
	}

	// Asıl gizleme işi mixin ile yapılacak
}

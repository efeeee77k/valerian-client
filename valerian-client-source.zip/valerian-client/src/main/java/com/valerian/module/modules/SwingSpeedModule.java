package com.valerian.module.modules;

import com.valerian.module.Category;
import com.valerian.module.Module;

public class SwingSpeedModule extends Module {

	// 1.0 = normal, daha düşük = daha yavaş animasyon
	public static float swingSpeed = 0.6f;

	public SwingSpeedModule() {
		super("SwingSpeed", Category.MISC, "Slows down hand swing animation (visual only)");
	}

	@Override
	public void onEnable() {
		swingSpeed = 0.55f; // yavaş kazıma efekti
	}

	@Override
	public void onDisable() {
		swingSpeed = 1.0f; // normale dön
	}
}

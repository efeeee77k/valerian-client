package com.valerian.module.modules;

import com.valerian.module.Category;
import com.valerian.module.Module;

public class SkinProtectModule extends Module {

	public SkinProtectModule() {
		super("SkinProtect", Category.MISC, "Protects your skin from being changed by others");
	}

	// Skin koruması genellikle sunucu tarafı veya paket filtreleme ister.
	// Şimdilik sadece toggle olarak duruyor, gerçek koruma sonra eklenecek.
}

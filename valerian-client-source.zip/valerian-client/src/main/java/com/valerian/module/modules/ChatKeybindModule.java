package com.valerian.module.modules;

import com.valerian.module.Category;
import com.valerian.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;

import java.util.HashMap;
import java.util.Map;

public class ChatKeybindModule extends Module {

	// Tuş kodu -> komut
	public static final Map<Integer, String> keybinds = new HashMap<>();

	static {
		// Örnek: R tuşu ile /spawn
		// keybinds.put(GLFW.GLFW_KEY_R, "/spawn");
	}

	public ChatKeybindModule() {
		super("ChatKeybind", Category.CLIENT, "Press a key to send a command");
	}

	public static void trySend(int keyCode) {
		if (!keybinds.containsKey(keyCode)) return;

		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.currentScreen != null) return;

		String command = keybinds.get(keyCode);
		mc.player.networkHandler.sendChatCommand(command.startsWith("/") ? command.substring(1) : command);
	}
}

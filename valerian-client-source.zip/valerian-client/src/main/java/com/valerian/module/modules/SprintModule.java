package com.valerian.module.modules;

import com.valerian.module.Category;
import com.valerian.module.Module;
import net.minecraft.client.MinecraftClient;

public class SprintModule extends Module {

	public SprintModule() {
		super("Sprint", Category.MISC, "Always sprint");
	}

	@Override
	public void onTick() {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player != null && mc.player.input != null) {
			// Basit always sprint
			if (mc.player.forwardSpeed > 0) {
				mc.player.setSprinting(true);
			}
		}
	}
}

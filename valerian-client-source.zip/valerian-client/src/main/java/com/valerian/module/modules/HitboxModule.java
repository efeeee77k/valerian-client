package com.valerian.module.modules;

import com.valerian.module.Category;
import com.valerian.module.Module;

public class HitboxModule extends Module {

	public HitboxModule() {
		super("Hitbox", Category.COMBAT, "Shows entity hitboxes");
	}

	@Override
	public void onEnable() {
		// Render kısmı sonra eklenecek (mixin ile)
	}

	@Override
	public void onDisable() {
	}
}

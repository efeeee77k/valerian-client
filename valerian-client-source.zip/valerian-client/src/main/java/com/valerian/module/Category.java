package com.valerian.module;

public enum Category {
	COMBAT("Combat"),
	MISC("Misc"),
	CLIENT("Client");

	public final String name;

	Category(String name) {
		this.name = name;
	}
}

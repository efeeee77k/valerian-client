package com.valerian.gui;

import com.valerian.module.Category;
import com.valerian.module.Module;
import com.valerian.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClickGuiScreen extends Screen {

	private static final int PANEL_WIDTH = 110;
	private static final int HEADER_HEIGHT = 18;
	private static final int MODULE_HEIGHT = 15;

	// Her kategorinin x pozisyonu
	private final Map<Category, Integer> categoryX = new HashMap<>();

	public ClickGuiScreen() {
		super(Text.literal("Valerian"));
	}

	@Override
	protected void init() {
		int x = 20;
		for (Category category : Category.values()) {
			categoryX.put(category, x);
			x += PANEL_WIDTH + 12;
		}
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		// Arka planı karart
		context.fill(0, 0, this.width, this.height, 0x90000000);

		for (Category category : Category.values()) {
			int x = categoryX.getOrDefault(category, 20);
			int y = 25;

			// Kategori başlığı
			context.fill(x, y, x + PANEL_WIDTH, y + HEADER_HEIGHT, 0xFF111122);
			context.drawCenteredTextWithShadow(this.textRenderer, category.name, x + PANEL_WIDTH / 2, y + 5, 0xFFFFFFFF);

			y += HEADER_HEIGHT;

			List<Module> modules = ModuleManager.getModulesByCategory(category);
			for (Module module : modules) {
				boolean enabled = module.isEnabled();
				boolean hovered = mouseX >= x && mouseX <= x + PANEL_WIDTH && mouseY >= y && mouseY <= y + MODULE_HEIGHT;

				int bgColor;
				if (enabled) {
					bgColor = hovered ? 0xFF00A844 : 0xFF00C853;
				} else {
					bgColor = hovered ? 0xFF3A3A5E : 0xFF222233;
				}

				context.fill(x, y, x + PANEL_WIDTH, y + MODULE_HEIGHT, bgColor);
				context.drawText(this.textRenderer, module.getName(), x + 6, y + 4, 0xFFFFFFFF, false);

				y += MODULE_HEIGHT + 1;
			}
		}

		// Alt bilgi
		context.drawText(this.textRenderer, "Valerian Client", 10, this.height - 15, 0xFFAAAAAA, false);

		super.render(context, mouseX, mouseY, delta);
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		if (button == 0) { // sol tık
			for (Category category : Category.values()) {
				int x = categoryX.getOrDefault(category, 20);
				int y = 25 + HEADER_HEIGHT;

				List<Module> modules = ModuleManager.getModulesByCategory(category);
				for (Module module : modules) {
					if (mouseX >= x && mouseX <= x + PANEL_WIDTH && mouseY >= y && mouseY <= y + MODULE_HEIGHT) {
						module.toggle();
						return true;
					}
					y += MODULE_HEIGHT + 1;
				}
			}
		}
		return super.mouseClicked(mouseX, mouseY, button);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}
}

package com.valerian.client;

import com.valerian.gui.ClickGuiScreen;
import com.valerian.hud.HudManager;
import com.valerian.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ValerianClient implements ClientModInitializer {

	public static KeyBinding openMenuKey;

	@Override
	public void onInitializeClient() {
		ModuleManager.init();
		HudManager.init();

		// Right Shift ile menüyü açma tuşu
		openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.valerian.openmenu",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_RIGHT_SHIFT,
				"category.valerian"
		));

		// HUD render
		HudRenderCallback.EVENT.register((context, tickCounter) -> {
			MinecraftClient mc = MinecraftClient.getInstance();
			if (mc.player != null && !mc.options.hudHidden) {
				HudManager.render(context);
			}
		});

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			// Modülleri tick'le
			ModuleManager.onTick();

			while (openMenuKey.wasPressed()) {
				MinecraftClient mc = MinecraftClient.getInstance();
				if (mc.currentScreen == null) {
					mc.setScreen(new ClickGuiScreen());
				} else if (mc.currentScreen instanceof ClickGuiScreen) {
					mc.setScreen(null);
				}
			}
		});

		System.out.println("[Valerian] Client initialized - Right Shift to open menu");
	}
}
